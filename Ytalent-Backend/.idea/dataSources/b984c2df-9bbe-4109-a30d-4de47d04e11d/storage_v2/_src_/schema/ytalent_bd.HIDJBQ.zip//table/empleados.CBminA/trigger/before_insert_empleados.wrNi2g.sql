create definer = root@localhost trigger before_insert_empleados
    before insert
    on empleados
    for each row
BEGIN
    IF NEW.fecha_nacimiento > CURDATE() OR YEAR(CURDATE()) - YEAR(NEW.fecha_nacimiento) > 100 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Fecha de nacimiento inválida';
    END IF;
END;

