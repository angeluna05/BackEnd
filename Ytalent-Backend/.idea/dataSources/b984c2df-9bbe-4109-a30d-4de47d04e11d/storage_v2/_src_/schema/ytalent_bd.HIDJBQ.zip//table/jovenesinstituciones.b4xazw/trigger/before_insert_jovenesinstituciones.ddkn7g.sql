create definer = root@localhost trigger before_insert_jovenesinstituciones
    before insert
    on jovenesinstituciones
    for each row
BEGIN
    IF NEW.fecha_inicio > NEW.fecha_fin THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La fecha de inicio debe ser anterior a la fecha de fin';
    END IF;
END;

